#!/bin/bash

echo "Instalando arte..."

chmod +x arte
sudo cp arte /usr/local/bin/arte

echo "Instalação concluída!"
echo "Digite no terminal:"
echo "arte"