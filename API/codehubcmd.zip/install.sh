#!/bin/bash

echo "Instalando firecmd..."

chmod +x firecmd
mv firecmd /usr/local/bin/firecmd

echo "Instalação concluída!"
echo "Agora você pode usar o comando:"
echo "firecmd"