#!/bin/bash

chmod +x firecmd
sudo mv firecmd /usr/local/bin/

echo "Instalado!"