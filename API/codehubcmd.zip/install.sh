#!/bin/bash

echo "Instalando codehubcmd..."

chmod +x codehubcmd
mv codehubcmd $PREFIX/bin/codehubcmd

echo "Instalação concluída!"
echo "Use o comando:"
echo "codehubcmd"