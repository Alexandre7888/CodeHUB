#!/bin/bash

# Instalação do bot como serviço systemd

BOT_DIR="$HOME/bot-terminal"
SERVICE_NAME="bot-terminal"

echo "🤖 Instalando Bot como serviço systemd..."

# Criar arquivo de serviço
sudo tee /etc/systemd/system/${SERVICE_NAME}.service > /dev/null << EOF
[Unit]
Description=Bot Terminal 24/7
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$BOT_DIR
ExecStart=/usr/bin/node $BOT_DIR/bot.js
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=${SERVICE_NAME}

[Install]
WantedBy=multi-user.target
EOF

# Recarregar systemd
sudo systemctl daemon-reload

echo "✅ Serviço instalado!"
echo ""
echo "Comandos disponíveis:"
echo "  sudo systemctl start ${SERVICE_NAME}   # Iniciar bot"
echo "  sudo systemctl stop ${SERVICE_NAME}    # Parar bot"
echo "  sudo systemctl status ${SERVICE_NAME}  # Ver status"
echo "  sudo systemctl enable ${SERVICE_NAME}  # Iniciar com o sistema"
echo "  sudo journalctl -u ${SERVICE_NAME} -f  # Ver logs"