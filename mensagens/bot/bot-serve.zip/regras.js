module.exports = [
  {
    name: 'Webhook de Gravação',
    type: 'webhook',
    url: 'https://seu-servidor.com/webhook/gravacao',
    event: 'call-ended',
    condition: 'true',
    action: `
      if (call.recording) {
        const recording = recordingManager.getRecording(call.recording);
        if (recording) {
          uploadToWebhook(recording, CONFIG.webhookUrl);
        }
      }
    `
  },
  {
    name: 'Notificar Admin sobre Chamada',
    event: 'call-created',
    condition: 'true',
    action: `
      console.log('Nova chamada criada:', call.id);
      // Enviar notificação para admin
      db.ref('notifications/admin').push({
        type: 'call-created',
        callId: call.id,
        host: call.host,
        timestamp: Date.now()
      });
    `
  },
  {
    name: 'Gravar Automaticamente',
    event: 'call-created',
    condition: 'call.type === "video"',
    action: `
      // Iniciar gravação automática para chamadas de vídeo
      setTimeout(() => {
        callManager.startCallRecording(call.id, 'video');
      }, 2000);
    `
  },
  {
    name: 'Log de Participantes',
    event: 'participant-joined',
    condition: 'true',
    action: `
      const logPath = path.join(__dirname, 'logs', 'participants.log');
      const log = \`[\${new Date().toISOString()}] Participante \${participant.name} (\${participant.id}) entrou na chamada \${callId}\n\`;
      fs.appendFileSync(logPath, log);
    `
  }
];