module.exports = [
  {
    name: '!oi',
    code: `
if (msg.text.toLowerCase() === '!oi' || msg.text.toLowerCase() === 'oi') {
  reply('👋 Olá ' + msg.senderName + '!');
}
    `
  },
  {
    name: '!ping',
    code: `
if (msg.text.toLowerCase() === '!ping') {
  reply('🏓 Pong!');
}
    `
  }
];