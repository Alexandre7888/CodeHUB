module.exports = [
  {
    name: '!oi',
    code: `
if (msg.text.toLowerCase() === '!oi' || msg.text.toLowerCase() === 'oi') {
  reply('👋 Olá ' + msg.senderName + '!');
}
    `
  },
  {
    name: '!ping',
    code: `
if (msg.text.toLowerCase() === '!ping') {
  reply('🏓 Pong!');
}
    `
  },
  {
    name: '!video',
    code: `
if (msg.text.toLowerCase().startsWith('!video')) {
  const args = msg.text.split(' ');
  let url = null;
  if (args.length > 1) url = args[1];
  iniciarChamadaVideo(url);
  if (url) {
    reply('📹 Chamada de vídeo iniciada!\\n🔗 ' + url);
  } else {
    reply('📷 Chamada de vídeo iniciada com câmera!');
  }
}
    `
  },
  {
    name: '!audio',
    code: `
if (msg.text.toLowerCase().startsWith('!audio')) {
  const args = msg.text.split(' ');
  if (args.length < 2) {
    reply('📋 Use: !audio [url]');
    return;
  }
  const url = args[1];
  iniciarChamadaAudio(url);
  reply('🎤 Chamada de áudio iniciada!\\n🎵 ' + url);
}
    `
  },
  {
    name: '!parar',
    code: `
if (msg.text.toLowerCase() === '!parar') {
  encerrarChamada();
  reply('🛑 Chamada encerrada!');
}
    `
  }
];