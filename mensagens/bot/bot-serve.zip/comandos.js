// Comandos padrão do bot
module.exports = [
  {
    name: '!ping',
    code: `
if (msg.text === '!ping') {
  reply('🏓 Pong!');
}
    `
  },
  {
    name: '!hora',
    code: `
if (msg.text === '!hora') {
  const agora = new Date();
  reply('🕐 ' + agora.toLocaleTimeString('pt-BR'));
}
    `
  },
  {
    name: '!info',
    code: `
if (msg.text === '!info') {
  reply('🤖 Bot: ' + bot.name + '\\n📅 Online desde: ' + new Date(bot.criadoEm).toLocaleString());
}
    `
  },
  {
    name: '!ajuda',
    code: `
if (msg.text === '!ajuda' || msg.text === '!help') {
  reply('📋 Comandos disponíveis:\\n!ping - Teste de conexão\\n!hora - Hora atual\\n!info - Info do bot\\n!dado - Rola um dado');
}
    `
  },
  {
    name: '!dado',
    code: `
if (msg.text === '!dado') {
  const resultado = Math.floor(Math.random() * 6) + 1;
  reply('🎲 Você rolou: ' + resultado);
}
    `
  }
];