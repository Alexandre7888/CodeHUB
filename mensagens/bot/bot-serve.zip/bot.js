#!/usr/bin/env node

const firebase = require('firebase');
const chalk = require('chalk');
const figlet = require('figlet');
const inquirer = require('inquirer');
const cron = require('node-cron');
const fs = require('fs');
const path = require('path');

// ============================================
// CONFIGURAÇÃO FIREBASE
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBzRLpZJDMeFASIjje4SJBfTInIEO-GKVI",
  databaseURL: "https://html-785e3-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ============================================
// ESTADO GLOBAL DO BOT
// ============================================
class BotTerminal {
  constructor() {
    this.bots = [];
    this.botAtivo = null;
    this.grupoAtivo = null;
    this.comandos = [];
    this.assets = [];
    this.executando = false;
    this.listeners = new Map();
    this.messageQueue = [];
    this.stats = {
      mensagensEnviadas: 0,
      mensagensRecebidas: 0,
      comandosExecutados: 0,
      uptime: Date.now()
    };
  }

  // ============================================
  // INICIALIZAÇÃO
  // ============================================
  async iniciar() {
    console.clear();
    
    // Banner ASCII
    console.log(chalk.cyan(figlet.textSync('BOT 24/7', {
      font: 'Standard',
      horizontalLayout: 'default',
      verticalLayout: 'default'
    })));

    console.log(chalk.green('╔══════════════════════════════════════════════════════════╗'));
    console.log(chalk.green('║        🤖 TERMINAL BOT - SERVIDOR LINUX 24/7              ║'));
    console.log(chalk.green('╚══════════════════════════════════════════════════════════╝'));
    
    // Carregar dados salvos
    await this.carregarDados();
    
    // Verificar conexão Firebase
    await this.verificarConexao();
    
    // Iniciar menu principal
    this.menuPrincipal();
  }

  // ============================================
  // CARREGAR DADOS SALVOS
  // ============================================
  async carregarDados() {
    const dataPath = path.join(__dirname, 'data.json');
    
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      this.bots = data.bots || [];
      this.comandos = data.comandos || [];
      this.assets = data.assets || [];
      console.log(chalk.yellow(`📦 Dados carregados: ${this.bots.length} bots, ${this.comandos.length} comandos`));
    }
    
    // Carregar comandos do arquivo separado
    try {
      const comandosModule = require('./comandos.js');
      this.comandos = [...this.comandos, ...comandosModule];
    } catch(e) {
      // Arquivo de comandos não existe ainda
    }
  }

  // ============================================
  // SALVAR DADOS
  // ============================================
  salvarDados() {
    const data = {
      bots: this.bots,
      comandos: this.comandos,
      assets: this.assets,
      ultimoBackup: Date.now()
    };
    
    fs.writeFileSync(path.join(__dirname, 'data.json'), JSON.stringify(data, null, 2));
    console.log(chalk.green('💾 Dados salvos com sucesso!'));
  }

  // ============================================
  // VERIFICAR CONEXÃO FIREBASE
  // ============================================
  async verificarConexao() {
    try {
      const connectedRef = db.ref('.info/connected');
      
      connectedRef.on('value', (snap) => {
        if (snap.val() === true) {
          console.log(chalk.green('✅ Conectado ao Firebase!'));
        } else {
          console.log(chalk.red('❌ Desconectado do Firebase!'));
        }
      });
    } catch (error) {
      console.error(chalk.red('Erro ao conectar ao Firebase:'), error);
    }
  }

  // ============================================
  // MENU PRINCIPAL
  // ============================================
  async menuPrincipal() {
    while (true) {
      const { opcao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcao',
          message: chalk.cyan('🤖 O que você quer fazer?'),
          choices: [
            { name: '📊 Dashboard - Ver Status', value: 'dashboard' },
            { name: '🤖 Gerenciar Bots', value: 'bots' },
            { name: '👥 Gerenciar Grupos', value: 'grupos' },
            { name: '📝 Gerenciar Comandos', value: 'comandos' },
            { name: '🎨 Gerenciar Assets', value: 'assets' },
            { name: '💬 Enviar Mensagem', value: 'enviar' },
            { name: '👀 Monitorar Mensagens', value: 'monitorar' },
            { name: '⚙️ Configurações', value: 'config' },
            { name: '🚀 Iniciar Bot 24/7', value: 'iniciar' },
            { name: '🛑 Parar Bot', value: 'parar' },
            { name: '📊 Estatísticas', value: 'stats' },
            new inquirer.Separator(),
            { name: '🚪 Sair', value: 'sair' }
          ],
          pageSize: 15
        }
      ]);

      if (opcao === 'sair') {
        await this.pararBot();
        console.log(chalk.yellow('👋 Até logo!'));
        process.exit(0);
      }

      await this.executarOpcao(opcao);
    }
  }

  // ============================================
  // EXECUTAR OPÇÃO DO MENU
  // ============================================
  async executarOpcao(opcao) {
    const handlers = {
      'dashboard': () => this.mostrarDashboard(),
      'bots': () => this.gerenciarBots(),
      'grupos': () => this.gerenciarGrupos(),
      'comandos': () => this.gerenciarComandos(),
      'assets': () => this.gerenciarAssets(),
      'enviar': () => this.enviarMensagem(),
      'monitorar': () => this.monitorarMensagens(),
      'config': () => this.configuracoes(),
      'iniciar': () => this.iniciarBot24h(),
      'parar': () => this.pararBot(),
      'stats': () => this.mostrarEstatisticas()
    };

    if (handlers[opcao]) {
      await handlers[opcao]();
    }
  }

  // ============================================
  // DASHBOARD
  // ============================================
  async mostrarDashboard() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 DASHBOARD\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    const status = this.executando ? chalk.green('✅ ATIVO') : chalk.yellow('⭕ INATIVO');
    console.log(`${chalk.white('Status:')} ${status}`);
    console.log(`${chalk.white('Bot Ativo:')} ${this.botAtivo ? chalk.cyan(this.botAtivo.name) : chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Grupo Ativo:')} ${this.grupoAtivo || chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Bots Cadastrados:')} ${chalk.yellow(this.bots.length)}`);
    console.log(`${chalk.white('Comandos:')} ${chalk.yellow(this.comandos.length)}`);
    console.log(`${chalk.white('Assets:')} ${chalk.yellow(this.assets.length)}`);
    
    const uptime = Math.floor((Date.now() - this.stats.uptime) / 1000);
    const horas = Math.floor(uptime / 3600);
    const minutos = Math.floor((uptime % 3600) / 60);
    const segundos = uptime % 60;
    
    console.log(`${chalk.white('Uptime:')} ${chalk.green(`${horas}h ${minutos}m ${segundos}s`)}`);
    console.log(`${chalk.white('Msgs Enviadas:')} ${chalk.blue(this.stats.mensagensEnviadas)}`);
    console.log(`${chalk.white('Msgs Recebidas:')} ${chalk.blue(this.stats.mensagensRecebidas)}`);
    console.log(`${chalk.white('Comandos Executados:')} ${chalk.blue(this.stats.comandosExecutados)}`);
    
    console.log(chalk.white('\n═'.repeat(50)));
    
    await inquirer.prompt([
      {
        type: 'input',
        name: 'continuar',
        message: 'Pressione ENTER para voltar...'
      }
    ]);
  }

  // ============================================
  // GERENCIAR BOTS
  // ============================================
  async gerenciarBots() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n🤖 GERENCIAR BOTS\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha uma ação:',
          choices: [
            { name: '➕ Criar Novo Bot', value: 'criar' },
            { name: '📋 Listar Bots', value: 'listar' },
            { name: '✅ Selecionar Bot', value: 'selecionar' },
            { name: '✏️ Editar Bot', value: 'editar' },
            { name: '🗑️ Deletar Bot', value: 'deletar' },
            { name: '📤 Exportar Bot', value: 'exportar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'criar':
          await this.criarBot();
          break;
        case 'listar':
          await this.listarBots();
          break;
        case 'selecionar':
          await this.selecionarBot();
          break;
        case 'editar':
          await this.editarBot();
          break;
        case 'deletar':
          await this.deletarBot();
          break;
        case 'exportar':
          await this.exportarBot();
          break;
      }
    }
  }

  async criarBot() {
    const respostas = await inquirer.prompt([
      {
        type: 'input',
        name: 'nome',
        message: 'Nome do bot:',
        validate: input => input.length > 0 ? true : 'Nome é obrigatório'
      },
      {
        type: 'input',
        name: 'avatar',
        message: 'URL do avatar (opcional):',
        default: 'https://i.imgur.com/2Vq5pZm.png'
      },
      {
        type: 'input',
        name: 'descricao',
        message: 'Descrição (opcional):',
        default: 'Bot criado via terminal'
      }
    ]);

    const id = `bot_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    const bot = {
      id,
      name: respostas.nome,
      avatar: respostas.avatar,
      descricao: respostas.descricao,
      criadoEm: Date.now(),
      status: 'offline',
      grupos: []
    };

    this.bots.push(bot);
    
    // Salvar no Firebase
    await db.ref(`users/${id}`).set({
      id,
      name: bot.name,
      avatar: bot.avatar,
      status: { state: 'offline', lastChanged: Date.now() }
    });
    
    await db.ref(`bots/${id}/messageCount`).set(0);
    
    this.salvarDados();
    
    console.log(chalk.green(`\n✅ Bot "${bot.name}" criado com sucesso!`));
    console.log(chalk.gray(`ID: ${bot.id}`));
    
    await this.pausa();
  }

  async listarBots() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 LISTA DE BOTS\n'));
    
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot cadastrado ainda.'));
    } else {
      this.bots.forEach((bot, index) => {
        const ativo = this.botAtivo?.id === bot.id ? chalk.green(' [ATIVO]') : '';
        console.log(chalk.white(`${index + 1}. ${bot.name}${ativo}`));
        console.log(chalk.gray(`   ID: ${bot.id}`));
        console.log(chalk.gray(`   Criado: ${new Date(bot.criadoEm).toLocaleString()}`));
        console.log('');
      });
    }
    
    await this.pausa();
  }

  async selecionarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot cadastrado. Crie um primeiro.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione um bot:',
        choices: this.bots.map(bot => ({
          name: `${bot.name} (${bot.id})`,
          value: bot.id
        }))
      }
    ]);

    this.botAtivo = this.bots.find(b => b.id === botId);
    console.log(chalk.green(`\n✅ Bot "${this.botAtivo.name}" selecionado!`));
    
    await this.pausa();
  }

  async editarBot() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    const respostas = await inquirer.prompt([
      {
        type: 'input',
        name: 'nome',
        message: 'Novo nome:',
        default: this.botAtivo.name
      },
      {
        type: 'input',
        name: 'avatar',
        message: 'Nova URL do avatar:',
        default: this.botAtivo.avatar
      }
    ]);

    this.botAtivo.name = respostas.nome;
    this.botAtivo.avatar = respostas.avatar;
    
    // Atualizar no Firebase
    await db.ref(`users/${this.botAtivo.id}`).update({
      name: respostas.nome,
      avatar: respostas.avatar
    });
    
    this.salvarDados();
    
    console.log(chalk.green(`\n✅ Bot atualizado com sucesso!`));
    await this.pausa();
  }

  async deletarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot para deletar.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione o bot para deletar:',
        choices: this.bots.map(bot => ({
          name: bot.name,
          value: bot.id
        }))
      }
    ]);

    const { confirmar } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmar',
        message: 'Tem certeza? Esta ação não pode ser desfeita!',
        default: false
      }
    ]);

    if (confirmar) {
      this.bots = this.bots.filter(b => b.id !== botId);
      
      if (this.botAtivo?.id === botId) {
        this.botAtivo = null;
      }
      
      // Remover do Firebase
      await db.ref(`users/${botId}`).remove();
      await db.ref(`bots/${botId}`).remove();
      
      this.salvarDados();
      console.log(chalk.green('✅ Bot deletado com sucesso!'));
    }
    
    await this.pausa();
  }

  async exportarBot() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    const exportData = {
      bot: this.botAtivo,
      comandos: this.comandos,
      exportadoEm: new Date().toISOString()
    };

    const filename = `bot_${this.botAtivo.id}_${Date.now()}.json`;
    fs.writeFileSync(filename, JSON.stringify(exportData, null, 2));
    
    console.log(chalk.green(`\n✅ Bot exportado para: ${filename}`));
    await this.pausa();
  }

  // ============================================
  // GERENCIAR GRUPOS
  // ============================================
  async gerenciarGrupos() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n👥 GERENCIAR GRUPOS\n'));
      console.log(chalk.white(`Bot ativo: ${chalk.cyan(this.botAtivo.name)}`));
      
      if (this.grupoAtivo) {
        console.log(chalk.white(`Grupo atual: ${chalk.green(this.grupoAtivo)}`));
      }
      
      console.log('');

      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha uma ação:',
          choices: [
            { name: '➕ Entrar em Grupo', value: 'entrar' },
            { name: '📋 Listar Grupos', value: 'listar' },
            { name: '✅ Selecionar Grupo', value: 'selecionar' },
            { name: '🚪 Sair do Grupo', value: 'sair' },
            { name: '👑 Verificar Role', value: 'role' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'entrar':
          await this.entrarGrupo();
          break;
        case 'listar':
          await this.listarGrupos();
          break;
        case 'selecionar':
          await this.selecionarGrupo();
          break;
        case 'sair':
          await this.sairGrupo();
          break;
        case 'role':
          await this.verificarRole();
          break;
      }
    }
  }

  async entrarGrupo() {
    const { grupoId } = await inquirer.prompt([
      {
        type: 'input',
        name: 'grupoId',
        message: 'ID do grupo:',
        validate: input => input.length > 0 ? true : 'ID é obrigatório'
      }
    ]);

    const snapshot = await db.ref(`groups/${grupoId}/members/${this.botAtivo.id}`).once('value');
    
    if (!snapshot.exists()) {
      await db.ref(`groups/${grupoId}/members/${this.botAtivo.id}`).set({
        id: this.botAtivo.id,
        name: this.botAtivo.name,
        role: 'member',
        joinedAt: Date.now()
      });
    }

    await db.ref(`bots/${this.botAtivo.id}/groups/${grupoId}`).set(Date.now());

    if (!this.botAtivo.grupos) this.botAtivo.grupos = [];
    if (!this.botAtivo.grupos.includes(grupoId)) {
      this.botAtivo.grupos.push(grupoId);
    }

    this.grupoAtivo = grupoId;
    this.salvarDados();

    console.log(chalk.green(`\n✅ Entrou no grupo ${grupoId} com sucesso!`));
    await this.pausa();
  }

  async listarGrupos() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 GRUPOS DO BOT\n'));
    
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Bot não está em nenhum grupo.'));
    } else {
      for (const grupoId of this.botAtivo.grupos) {
        const snapshot = await db.ref(`groups/${grupoId}`).once('value');
        const grupo = snapshot.val() || {};
        
        const membros = grupo.members ? Object.keys(grupo.members).length : 0;
        const ativo = this.grupoAtivo === grupoId ? chalk.green(' [ATIVO]') : '';
        
        console.log(chalk.white(`📌 Grupo: ${grupoId}${ativo}`));
        console.log(chalk.gray(`   Membros: ${membros}`));
        console.log('');
      }
    }
    
    await this.pausa();
  }

  async selecionarGrupo() {
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Bot não está em nenhum grupo.'));
      await this.pausa();
      return;
    }

    const { grupoId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'grupoId',
        message: 'Selecione um grupo:',
        choices: this.botAtivo.grupos.map(id => ({
          name: id,
          value: id
        }))
      }
    ]);

    this.grupoAtivo = grupoId;
    console.log(chalk.green(`\n✅ Grupo ${grupoId} selecionado!`));
    await this.pausa();
  }

  async sairGrupo() {
    if (!this.grupoAtivo) {
      console.log(chalk.yellow('Nenhum grupo selecionado.'));
      await this.pausa();
      return;
    }

    const { confirmar } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmar',
        message: `Sair do grupo ${this.grupoAtivo}?`,
        default: false
      }
    ]);

    if (confirmar) {
      await db.ref(`groups/${this.grupoAtivo}/members/${this.botAtivo.id}`).remove();
      await db.ref(`bots/${this.botAtivo.id}/groups/${this.grupoAtivo}`).remove();
      
      this.botAtivo.grupos = this.botAtivo.grupos.filter(g => g !== this.grupoAtivo);
      this.grupoAtivo = null;
      
      this.salvarDados();
      console.log(chalk.green('✅ Saiu do grupo com sucesso!'));
    }
    
    await this.pausa();
  }

  async verificarRole() {
    if (!this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um grupo primeiro.'));
      await this.pausa();
      return;
    }

    const snapshot = await db.ref(`groups/${this.grupoAtivo}/members/${this.botAtivo.id}`).once('value');
    const data = snapshot.val();
    
    if (data) {
      console.log(chalk.cyan(`\n👑 Role no grupo ${this.grupoAtivo}: ${chalk.bold(data.role)}`));
      console.log(chalk.gray(`Entrou em: ${new Date(data.joinedAt).toLocaleString()}`));
    } else {
      console.log(chalk.yellow('Bot não está neste grupo.'));
    }
    
    await this.pausa();
  }

  // ============================================
  // GERENCIAR COMANDOS
  // ============================================
  async gerenciarComandos() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n📝 GERENCIAR COMANDOS\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha uma ação:',
          choices: [
            { name: '➕ Adicionar Comando', value: 'adicionar' },
            { name: '📋 Listar Comandos', value: 'listar' },
            { name: '✏️ Editar Comando', value: 'editar' },
            { name: '🗑️ Deletar Comando', value: 'deletar' },
            { name: '🧪 Testar Comando', value: 'testar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'adicionar':
          await this.adicionarComando();
          break;
        case 'listar':
          await this.listarComandos();
          break;
        case 'editar':
          await this.editarComando();
          break;
        case 'deletar':
          await this.deletarComando();
          break;
        case 'testar':
          await this.testarComando();
          break;
      }
    }
  }

  async adicionarComando() {
    const respostas = await inquirer.prompt([
      {
        type: 'input',
        name: 'nome',
        message: 'Nome do comando (ex: !oi):',
        validate: input => input.length > 0 ? true : 'Nome é obrigatório'
      },
      {
        type: 'editor',
        name: 'codigo',
        message: 'Código do comando (JavaScript):',
        default: `// Exemplo:
if (msg.text === '!ping') {
  reply('🏓 Pong!');
}

// Variáveis disponíveis:
// msg - objeto da mensagem
// reply(texto) - função para responder
// bot - dados do bot
// grupo - ID do grupo
// db - referência do Firebase`
      }
    ]);

    const comando = {
      name: respostas.nome,
      code: respostas.codigo,
      criadoEm: Date.now()
    };

    this.comandos.push(comando);
    this.salvarDados();

    console.log(chalk.green(`\n✅ Comando "${respostas.nome}" adicionado!`));
    await this.pausa();
  }

  async listarComandos() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 LISTA DE COMANDOS\n'));
    
    if (this.comandos.length === 0) {
      console.log(chalk.yellow('Nenhum comando cadastrado.'));
    } else {
      this.comandos.forEach((cmd, index) => {
        console.log(chalk.white(`${index + 1}. ${cmd.name}`));
        console.log(chalk.gray(`   ${cmd.code.split('\n')[0].substring(0, 50)}...`));
        console.log('');
      });
    }
    
    await this.pausa();
  }

  async editarComando() {
    if (this.comandos.length === 0) {
      console.log(chalk.yellow('Nenhum comando para editar.'));
      await this.pausa();
      return;
    }

    const { comandoNome } = await inquirer.prompt([
      {
        type: 'list',
        name: 'comandoNome',
        message: 'Selecione o comando:',
        choices: this.comandos.map(cmd => ({
          name: cmd.name,
          value: cmd.name
        }))
      }
    ]);

    const comando = this.comandos.find(c => c.name === comandoNome);

    const respostas = await inquirer.prompt([
      {
        type: 'editor',
        name: 'codigo',
        message: 'Edite o código:',
        default: comando.code
      }
    ]);

    comando.code = respostas.codigo;
    this.salvarDados();

    console.log(chalk.green(`\n✅ Comando "${comandoNome}" atualizado!`));
    await this.pausa();
  }

  async deletarComando() {
    if (this.comandos.length === 0) {
      console.log(chalk.yellow('Nenhum comando para deletar.'));
      await this.pausa();
      return;
    }

    const { comandoNome } = await inquirer.prompt([
      {
        type: 'list',
        name: 'comandoNome',
        message: 'Selecione o comando para deletar:',
        choices: this.comandos.map(cmd => ({
          name: cmd.name,
          value: cmd.name
        }))
      }
    ]);

    this.comandos = this.comandos.filter(c => c.name !== comandoNome);
    this.salvarDados();

    console.log(chalk.green(`\n✅ Comando "${comandoNome}" deletado!`));
    await this.pausa();
  }

  async testarComando() {
    if (this.comandos.length === 0) {
      console.log(chalk.yellow('Nenhum comando para testar.'));
      await this.pausa();
      return;
    }

    const { comandoNome } = await inquirer.prompt([
      {
        type: 'list',
        name: 'comandoNome',
        message: 'Selecione o comando para testar:',
        choices: this.comandos.map(cmd => ({
          name: cmd.name,
          value: cmd.name
        }))
      }
    ]);

    const comando = this.comandos.find(c => c.name === comandoNome);

    const { mensagem } = await inquirer.prompt([
      {
        type: 'input',
        name: 'mensagem',
        message: 'Digite uma mensagem de teste:',
        default: comando.name
      }
    ]);

    // Simular mensagem para teste
    const msgSimulada = {
      text: mensagem,
      senderId: 'test_user',
      senderName: 'Usuário Teste',
      timestamp: Date.now()
    };

    console.log(chalk.cyan('\n🧪 Executando comando...\n'));

    try {
      const reply = (texto) => {
        console.log(chalk.green('💬 Resposta do bot:'), chalk.white(texto));
      };

      eval(comando.code);
      
      this.stats.comandosExecutados++;
    } catch (error) {
      console.log(chalk.red('❌ Erro no comando:'), error.message);
    }

    await this.pausa();
  }

  // ============================================
  // GERENCIAR ASSETS
  // ============================================
  async gerenciarAssets() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n🎨 GERENCIAR ASSETS\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha uma ação:',
          choices: [
            { name: '➕ Adicionar Asset', value: 'adicionar' },
            { name: '📋 Listar Assets', value: 'listar' },
            { name: '🗑️ Deletar Asset', value: 'deletar' },
            { name: '📤 Enviar Asset para Grupo', value: 'enviar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'adicionar':
          await this.adicionarAsset();
          break;
        case 'listar':
          await this.listarAssets();
          break;
        case 'deletar':
          await this.deletarAsset();
          break;
        case 'enviar':
          await this.enviarAsset();
          break;
      }
    }
  }

  async adicionarAsset() {
    const respostas = await inquirer.prompt([
      {
        type: 'input',
        name: 'nome',
        message: 'Nome do asset:',
        validate: input => input.length > 0 ? true : 'Nome é obrigatório'
      },
      {
        type: 'input',
        name: 'url',
        message: 'URL do arquivo:',
        validate: input => input.length > 0 ? true : 'URL é obrigatória'
      },
      {
        type: 'list',
        name: 'tipo',
        message: 'Tipo do asset:',
        choices: ['imagem', 'audio', 'video', 'documento', 'outro']
      }
    ]);

    const asset = {
      id: `asset_${Date.now()}`,
      name: respostas.nome,
      url: respostas.url,
      type: respostas.tipo,
      addedAt: Date.now()
    };

    this.assets.push(asset);
    this.salvarDados();

    console.log(chalk.green(`\n✅ Asset "${respostas.nome}" adicionado!`));
    await this.pausa();
  }

  async listarAssets() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 LISTA DE ASSETS\n'));
    
    if (this.assets.length === 0) {
      console.log(chalk.yellow('Nenhum asset cadastrado.'));
    } else {
      this.assets.forEach((asset, index) => {
        console.log(chalk.white(`${index + 1}. ${asset.name}`));
        console.log(chalk.gray(`   Tipo: ${asset.type}`));
        console.log(chalk.gray(`   URL: ${asset.url.substring(0, 50)}...`));
        console.log('');
      });
    }
    
    await this.pausa();
  }

  async deletarAsset() {
    if (this.assets.length === 0) {
      console.log(chalk.yellow('Nenhum asset para deletar.'));
      await this.pausa();
      return;
    }

    const { assetIndex } = await inquirer.prompt([
      {
        type: 'list',
        name: 'assetIndex',
        message: 'Selecione o asset para deletar:',
        choices: this.assets.map((asset, index) => ({
          name: asset.name,
          value: index
        }))
      }
    ]);

    this.assets.splice(assetIndex, 1);
    this.salvarDados();

    console.log(chalk.green(`\n✅ Asset deletado!`));
    await this.pausa();
  }

  async enviarAsset() {
    if (!this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um grupo primeiro.'));
      await this.pausa();
      return;
    }

    if (this.assets.length === 0) {
      console.log(chalk.yellow('Nenhum asset para enviar.'));
      await this.pausa();
      return;
    }

    const { assetIndex } = await inquirer.prompt([
      {
        type: 'list',
        name: 'assetIndex',
        message: 'Selecione o asset para enviar:',
        choices: this.assets.map((asset, index) => ({
          name: asset.name,
          value: index
        }))
      }
    ]);

    const asset = this.assets[assetIndex];

    await this.enviarMensagemFirebase(asset.url, asset.type);
    
    console.log(chalk.green(`\n✅ Asset enviado para o grupo!`));
    await this.pausa();
  }

  // ============================================
  // ENVIAR MENSAGEM
  // ============================================
  async enviarMensagem() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro.'));
      await this.pausa();
      return;
    }

    if (!this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um grupo primeiro.'));
      await this.pausa();
      return;
    }

    const { mensagem } = await inquirer.prompt([
      {
        type: 'input',
        name: 'mensagem',
        message: 'Digite a mensagem:',
        validate: input => input.length > 0 ? true : 'Mensagem é obrigatória'
      }
    ]);

    await this.enviarMensagemFirebase(mensagem);
    
    console.log(chalk.green(`\n✅ Mensagem enviada!`));
    await this.pausa();
  }

  async enviarMensagemFirebase(texto, tipo = 'text') {
    const timestamp = Date.now();
    const horaFormatada = new Date(timestamp).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });

    const mensagem = {
      senderId: this.botAtivo.id,
      senderName: this.botAtivo.name,
      text: texto,
      timestamp: timestamp,
      time: horaFormatada,
      type: tipo,
      readBy: {
        [this.botAtivo.id]: timestamp
      }
    };

    await db.ref(`groups/${this.grupoAtivo}/messages`).push(mensagem);
    
    // Incrementar contador
    await db.ref(`bots/${this.botAtivo.id}/messageCount`)
      .transaction(v => (v || 0) + 1);
    
    this.stats.mensagensEnviadas++;
  }

  // ============================================
  // MONITORAR MENSAGENS
  // ============================================
  async monitorarMensagens() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um bot e um grupo primeiro.'));
      await this.pausa();
      return;
    }

    console.clear();
    console.log(chalk.cyan.bold('\n👀 MONITORANDO MENSAGENS\n'));
    console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.name)}`));
    console.log(chalk.white(`Grupo: ${chalk.cyan(this.grupoAtivo)}`));
    console.log(chalk.yellow('\nPressione CTRL+C para parar de monitorar\n'));
    console.log(chalk.white('═'.repeat(60)));

    // Configurar listener
    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    const onMessage = (snapshot) => {
      const msg = snapshot.val();
      
      // Ignorar mensagens do próprio bot
      if (msg.senderId === this.botAtivo.id) return;
      
      const hora = msg.time || new Date(msg.timestamp).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      });
      
      console.log(chalk.gray(`[${hora}]`), 
                  chalk.cyan(msg.senderName + ':'), 
                  chalk.white(msg.text || '[Mídia]'));
      
      this.stats.mensagensRecebidas++;
      
      // Executar comandos automaticamente
      this.executarComandos(msg);
    };

    messagesRef.limitToLast(1).on('child_added', onMessage);

    // Manter o monitoramento ativo
    await new Promise(resolve => {
      process.on('SIGINT', () => {
        messagesRef.off('child_added', onMessage);
        console.log(chalk.yellow('\n\n👋 Monitoramento encerrado.'));
        resolve();
        setTimeout(() => this.menuPrincipal(), 1000);
      });
    });
  }

  // ============================================
  // EXECUTAR COMANDOS
  // ============================================
  executarComandos(msg) {
    if (!msg.text) return;

    for (const comando of this.comandos) {
      try {
        const reply = (texto) => {
          this.enviarMensagemFirebase(texto);
        };

        // Contexto para o eval
        const bot = this.botAtivo;
        const grupo = this.grupoAtivo;
        
        eval(comando.code);
        
        this.stats.comandosExecutados++;
      } catch (error) {
        console.error(chalk.red(`Erro no comando ${comando.name}:`), error.message);
      }
    }
  }

  // ============================================
  // CONFIGURAÇÕES
  // ============================================
  async configuracoes() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n⚙️ CONFIGURAÇÕES\n'));
      
      const { opcao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcao',
          message: 'Escolha uma opção:',
          choices: [
            { name: '💾 Fazer Backup', value: 'backup' },
            { name: '📂 Restaurar Backup', value: 'restaurar' },
            { name: '🔄 Resetar Estatísticas', value: 'reset' },
            { name: '📤 Exportar Tudo', value: 'exportar' },
            { name: '📥 Importar Dados', value: 'importar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (opcao === 'voltar') break;

      switch (opcao) {
        case 'backup':
          this.salvarDados();
          console.log(chalk.green('\n✅ Backup criado com sucesso!'));
          await this.pausa();
          break;
        case 'reset':
          this.stats = {
            mensagensEnviadas: 0,
            mensagensRecebidas: 0,
            comandosExecutados: 0,
            uptime: Date.now()
          };
          console.log(chalk.green('\n✅ Estatísticas resetadas!'));
          await this.pausa();
          break;
        case 'exportar':
          const exportFile = `backup_${Date.now()}.json`;
          fs.writeFileSync(exportFile, JSON.stringify({
            bots: this.bots,
            comandos: this.comandos,
            assets: this.assets,
            stats: this.stats
          }, null, 2));
          console.log(chalk.green(`\n✅ Dados exportados para: ${exportFile}`));
          await this.pausa();
          break;
        default:
          await this.pausa();
      }
    }
  }

  // ============================================
  // INICIAR BOT 24/7
  // ============================================
  async iniciarBot24h() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro.'));
      await this.pausa();
      return;
    }

    if (!this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um grupo primeiro.'));
      await this.pausa();
      return;
    }

    this.executando = true;

    console.clear();
    console.log(chalk.green.bold('\n🚀 INICIANDO BOT 24/7\n'));
    console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.name)}`));
    console.log(chalk.white(`Grupo: ${chalk.cyan(this.grupoAtivo)}`));
    console.log(chalk.white(`Comandos carregados: ${chalk.yellow(this.comandos.length)}`));
    console.log(chalk.green('\n✅ Bot iniciado em segundo plano!'));
    console.log(chalk.yellow('O bot continuará rodando mesmo após fechar o terminal.\n'));

    // Configurar listener permanente
    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    messagesRef.on('child_added', (snapshot) => {
      const msg = snapshot.val();
      
      if (msg.senderId !== this.botAtivo.id) {
        this.executarComandos(msg);
        this.stats.mensagensRecebidas++;
      }
    });

    // Atualizar status no Firebase
    await db.ref(`users/${this.botAtivo.id}/status`).set({
      state: 'online',
      lastChanged: Date.now()
    });

    // Configurar heartbeat
    setInterval(async () => {
      await db.ref(`bots/${this.botAtivo.id}/heartbeat`).set(Date.now());
    }, 30000);

    console.log(chalk.gray('\nPressione qualquer tecla para voltar ao menu...'));
    await this.pausa();
  }

  // ============================================
  // PARAR BOT
  // ============================================
  async pararBot() {
    if (!this.executando) {
      console.log(chalk.yellow('Bot não está em execução.'));
      await this.pausa();
      return;
    }

    this.executando = false;

    // Remover listeners
    if (this.grupoAtivo) {
      db.ref(`groups/${this.grupoAtivo}/messages`).off();
    }

    // Atualizar status
    if (this.botAtivo) {
      await db.ref(`users/${this.botAtivo.id}/status`).set({
        state: 'offline',
        lastChanged: Date.now()
      });
    }

    console.log(chalk.yellow('\n🛑 Bot parado.'));
    await this.pausa();
  }

  // ============================================
  // ESTATÍSTICAS
  // ============================================
  async mostrarEstatisticas() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 ESTATÍSTICAS DETALHADAS\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    const uptime = Math.floor((Date.now() - this.stats.uptime) / 1000);
    const horas = Math.floor(uptime / 3600);
    const minutos = Math.floor((uptime % 3600) / 60);
    const segundos = uptime % 60;
    
    console.log(chalk.white(`⏱️  Uptime: ${chalk.green(`${horas}h ${minutos}m ${segundos}s`)}`));
    console.log(chalk.white(`📨 Mensagens Enviadas: ${chalk.blue(this.stats.mensagensEnviadas)}`));
    console.log(chalk.white(`📥 Mensagens Recebidas: ${chalk.blue(this.stats.mensagensRecebidas)}`));
    console.log(chalk.white(`⚡ Comandos Executados: ${chalk.blue(this.stats.comandosExecutados)}`));
    
    if (this.stats.mensagensRecebidas > 0) {
      const taxa = (this.stats.comandosExecutados / this.stats.mensagensRecebidas * 100).toFixed(1);
      console.log(chalk.white(`📊 Taxa de Resposta: ${chalk.green(taxa + '%')}`));
    }
    
    console.log(chalk.white(`\n🤖 Bots: ${chalk.yellow(this.bots.length)}`));
    console.log(chalk.white(`📝 Comandos: ${chalk.yellow(this.comandos.length)}`));
    console.log(chalk.white(`🎨 Assets: ${chalk.yellow(this.assets.length)}`));
    
    console.log(chalk.white('\n═'.repeat(50)));
    
    await this.pausa();
  }

  // ============================================
  // UTILITÁRIOS
  // ============================================
  async pausa() {
    await inquirer.prompt([
      {
        type: 'input',
        name: 'continuar',
        message: chalk.gray('\nPressione ENTER para continuar...')
      }
    ]);
  }
}

// ============================================
// INICIAR BOT
// ============================================
const bot = new BotTerminal();

// Tratamento de erros
process.on('unhandledRejection', (error) => {
  console.error(chalk.red('Erro não tratado:'), error);
});

process.on('SIGINT', async () => {
  console.log(chalk.yellow('\n\n🛑 Encerrando bot...'));
  await bot.pararBot();
  process.exit(0);
});

// Iniciar
bot.iniciar().catch(console.error);

// Exportar para uso como módulo
module.exports = BotTerminal;