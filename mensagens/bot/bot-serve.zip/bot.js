#!/usr/bin/env node

const firebase = require('firebase');
const chalk = require('chalk');
const figlet = require('figlet');
const inquirer = require('inquirer');
const fs = require('fs');
const path = require('path');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const os = require('os');
const { PeerServer } = require('peer');

// ============================================
// CONFIGURAÇÃO FIREBASE
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBzRLpZJDMeFASIjje4SJBfTInIEO-GKVI",
  databaseURL: "https://html-785e3-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ============================================
// CONFIGURAÇÃO DO SERVIDOR WEB E PEERJS
// ============================================
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: { origin: "*", methods: ["GET", "POST"] }
});

const WEB_PORT = 3000;
const PEER_PORT = 9000;

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/api/info', (req, res) => {
  const networkInterfaces = os.networkInterfaces();
  const ips = [];
  
  for (const name of Object.keys(networkInterfaces)) {
    for (const net of networkInterfaces[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        ips.push(net.address);
      }
    }
  }
  
  res.json({
    ips: ips,
    webPort: WEB_PORT,
    peerPort: PEER_PORT,
    url: ips.length > 0 ? `http://${ips[0]}:${WEB_PORT}` : `http://localhost:${WEB_PORT}`,
    botAtivo: bot.botAtivo ? bot.botAtivo.name : null,
    grupoAtivo: bot.grupoAtivo,
    chamadaAtiva: bot.chamadaAtiva
  });
});

// WebSocket para signaling
io.on('connection', (socket) => {
  console.log(chalk.green(`🔗 Cliente conectado: ${socket.id}`));
  
  socket.on('join-room', (roomId) => {
    socket.join(roomId);
    socket.to(roomId).emit('user-connected', socket.id);
  });
  
  socket.on('offer', (data) => {
    socket.to(data.roomId).emit('offer', { offer: data.offer, from: socket.id });
  });
  
  socket.on('answer', (data) => {
    socket.to(data.roomId).emit('answer', { answer: data.answer, from: socket.id });
  });
  
  socket.on('ice-candidate', (data) => {
    socket.to(data.roomId).emit('ice-candidate', { candidate: data.candidate, from: socket.id });
  });
  
  socket.on('disconnect', () => {
    console.log(chalk.yellow(`🔌 Cliente desconectado: ${socket.id}`));
    io.emit('user-disconnected', socket.id);
  });
});

// ============================================
// CLASSE PRINCIPAL DO BOT
// ============================================
class BotTerminal {
  constructor() {
    this.bots = [];
    this.botAtivo = null;
    this.grupoAtivo = null;
    this.comandos = [];
    this.assets = [];
    this.executando = false;
    this.chamadaAtiva = false;
    this.tipoChamada = null;
    this.urlMidia = null;
    this.serverUrl = '';
    this.peerServer = null;
    this.stats = {
      mensagensEnviadas: 0,
      mensagensRecebidas: 0,
      comandosExecutados: 0,
      uptime: Date.now()
    };
  }

  async iniciar() {
    console.clear();
    
    console.log(chalk.cyan(figlet.textSync('BOT SERVER', {
      font: 'Standard',
      horizontalLayout: 'default',
      verticalLayout: 'default'
    })));

    console.log(chalk.green('╔══════════════════════════════════════════════════════════╗'));
    console.log(chalk.green('║           🤖 BOT SERVER - WEBRTC + FIREBASE              ║'));
    console.log(chalk.green('║       Mensagens • Chamadas • Streaming                   ║'));
    console.log(chalk.green('╚══════════════════════════════════════════════════════════╝'));
    
    await this.carregarDados();
    await this.verificarConexao();
    
    this.iniciarPeerServer();
    this.iniciarServidorWeb();
    this.mostrarUrlsAcesso();
    
    this.menuPrincipal();
  }

  iniciarPeerServer() {
    try {
      this.peerServer = PeerServer({
        port: PEER_PORT,
        path: '/peerjs',
        allow_discovery: true
      });
      
      console.log(chalk.green(`✅ Servidor PeerJS rodando na porta ${PEER_PORT}`));
    } catch (error) {
      console.log(chalk.red('❌ Erro ao iniciar PeerJS:'), error.message);
    }
  }

  iniciarServidorWeb() {
    server.listen(WEB_PORT, '0.0.0.0', () => {
      console.log(chalk.green(`✅ Servidor Web rodando na porta ${WEB_PORT}`));
    });
  }

  mostrarUrlsAcesso() {
    const networkInterfaces = os.networkInterfaces();
    
    console.log(chalk.cyan('\n🌐 URLs de Acesso:\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    for (const name of Object.keys(networkInterfaces)) {
      for (const net of networkInterfaces[name]) {
        if (net.family === 'IPv4') {
          const url = `http://${net.address}:${WEB_PORT}`;
          if (!net.internal) {
            console.log(chalk.green(`   📡 Rede: ${url}`));
            this.serverUrl = url;
          }
        }
      }
    }
    
    console.log(chalk.white('═'.repeat(50)));
    console.log(chalk.cyan('\n📱 Acesse pelo navegador para fazer chamadas!\n'));
  }

  async carregarDados() {
    const dataPath = path.join(__dirname, 'dados.json');
    
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      this.bots = data.bots || [];
      this.comandos = data.comandos || [];
      this.assets = data.assets || [];
      console.log(chalk.yellow(`📦 ${this.bots.length} bots carregados`));
    }
    
    try {
      const comandosModule = require('./comandos.js');
      this.comandos = [...this.comandos, ...comandosModule];
    } catch(e) {}
  }

  salvarDados() {
    const data = {
      bots: this.bots,
      comandos: this.comandos,
      assets: this.assets
    };
    
    fs.writeFileSync(path.join(__dirname, 'dados.json'), JSON.stringify(data, null, 2));
    console.log(chalk.green('💾 Dados salvos'));
  }

  async verificarConexao() {
    try {
      const connectedRef = db.ref('.info/connected');
      connectedRef.on('value', (snap) => {
        if (snap.val() === true) {
          console.log(chalk.green('✅ Conectado ao Firebase'));
        } else {
          console.log(chalk.red('❌ Desconectado do Firebase'));
        }
      });
    } catch (error) {}
  }

  async menuPrincipal() {
    while (true) {
      const { opcao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcao',
          message: chalk.cyan('🤖 Menu Principal:'),
          choices: [
            { name: '📊 Dashboard', value: 'dashboard' },
            { name: '🤖 Gerenciar Bots', value: 'bots' },
            { name: '👥 Gerenciar Grupos', value: 'grupos' },
            { name: '📝 Gerenciar Comandos', value: 'comandos' },
            { name: '📞 Chamadas', value: 'chamadas' },
            { name: '🌐 URLs de Acesso', value: 'urls' },
            { name: '💬 Enviar Mensagem', value: 'enviar' },
            { name: '👀 Monitorar Mensagens', value: 'monitorar' },
            { name: '🚀 Iniciar 24/7', value: 'iniciar' },
            { name: '🛑 Parar', value: 'parar' },
            new inquirer.Separator(),
            { name: '🚪 Sair', value: 'sair' }
          ]
        }
      ]);

      if (opcao === 'sair') {
        await this.parar();
        console.log(chalk.yellow('👋 Até logo!'));
        server.close();
        if (this.peerServer) this.peerServer.close();
        process.exit(0);
      }

      await this.executarOpcao(opcao);
    }
  }

  async executarOpcao(opcao) {
    const handlers = {
      'dashboard': () => this.mostrarDashboard(),
      'bots': () => this.gerenciarBots(),
      'grupos': () => this.gerenciarGrupos(),
      'comandos': () => this.gerenciarComandos(),
      'chamadas': () => this.gerenciarChamadas(),
      'urls': () => this.mostrarUrlsAcesso(),
      'enviar': () => this.enviarMensagem(),
      'monitorar': () => this.monitorarMensagens(),
      'iniciar': () => this.iniciar24h(),
      'parar': () => this.parar()
    };

    if (handlers[opcao]) {
      await handlers[opcao]();
    }
  }

  async mostrarDashboard() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 DASHBOARD\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    const status = this.executando ? chalk.green('✅ ATIVO') : chalk.yellow('⭕ INATIVO');
    console.log(`${chalk.white('Status:')} ${status}`);
    console.log(`${chalk.white('Bot:')} ${this.botAtivo ? chalk.cyan(this.botAtivo.name) : chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Grupo:')} ${this.grupoAtivo || chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Bots:')} ${chalk.yellow(this.bots.length)}`);
    console.log(`${chalk.white('URL Web:')} ${chalk.cyan(this.serverUrl)}`);
    console.log(`${chalk.white('PeerJS:')} ${chalk.cyan(`porta ${PEER_PORT}`)}`);
    
    if (this.chamadaAtiva) {
      console.log(`${chalk.white('Chamada:')} ${chalk.green(this.tipoChamada)}`);
    }
    
    console.log(chalk.white('\n═'.repeat(50)));
    await this.pausa();
  }

  async gerenciarBots() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n🤖 GERENCIAR BOTS\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha:',
          choices: [
            { name: '➕ Criar Bot', value: 'criar' },
            { name: '📋 Listar Bots', value: 'listar' },
            { name: '✅ Selecionar Bot', value: 'selecionar' },
            { name: '🗑️ Deletar Bot', value: 'deletar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'criar': await this.criarBot(); break;
        case 'listar': await this.listarBots(); break;
        case 'selecionar': await this.selecionarBot(); break;
        case 'deletar': await this.deletarBot(); break;
      }
    }
  }

  async criarBot() {
    const respostas = await inquirer.prompt([
      { type: 'input', name: 'nome', message: 'Nome do bot:' },
      { type: 'input', name: 'avatar', message: 'URL do avatar:', default: 'https://i.imgur.com/2Vq5pZm.png' }
    ]);

    const id = `bot_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    this.bots.push({
      id,
      name: respostas.nome,
      avatar: respostas.avatar,
      criadoEm: Date.now(),
      grupos: []
    });

    this.salvarDados();
    await db.ref(`users/${id}`).set({ id, name: respostas.nome, avatar: respostas.avatar });
    console.log(chalk.green(`\n✅ Bot "${respostas.nome}" criado!`));
    await this.pausa();
  }

  async listarBots() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 BOTS\n'));
    
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot cadastrado.'));
    } else {
      this.bots.forEach((bot, i) => {
        const ativo = this.botAtivo?.id === bot.id ? chalk.green(' [ATIVO]') : '';
        console.log(chalk.white(`${i + 1}. ${bot.name}${ativo}`));
      });
    }
    
    await this.pausa();
  }

  async selecionarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot cadastrado.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione um bot:',
        choices: this.bots.map(b => ({ name: b.name, value: b.id }))
      }
    ]);

    this.botAtivo = this.bots.find(b => b.id === botId);
    
    await db.ref(`bots/${this.botAtivo.id}/peer`).set(this.botAtivo.id.replace(/[^a-zA-Z0-9]/g, ''));
    
    console.log(chalk.green(`\n✅ Bot "${this.botAtivo.name}" selecionado!`));
    await this.pausa();
  }

  async deletarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot para deletar.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione para deletar:',
        choices: this.bots.map(b => ({ name: b.name, value: b.id }))
      }
    ]);

    const { confirmar } = await inquirer.prompt([
      { type: 'confirm', name: 'confirmar', message: 'Tem certeza?', default: false }
    ]);

    if (confirmar) {
      this.bots = this.bots.filter(b => b.id !== botId);
      if (this.botAtivo?.id === botId) this.botAtivo = null;
      this.salvarDados();
      await db.ref(`users/${botId}`).remove();
      console.log(chalk.green('✅ Bot deletado!'));
    }
    
    await this.pausa();
  }

  async gerenciarGrupos() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n👥 GERENCIAR GRUPOS\n'));
      console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.name)}`));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha:',
          choices: [
            { name: '➕ Entrar em Grupo', value: 'entrar' },
            { name: '📋 Listar Grupos', value: 'listar' },
            { name: '✅ Selecionar Grupo', value: 'selecionar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'entrar': await this.entrarGrupo(); break;
        case 'listar': await this.listarGrupos(); break;
        case 'selecionar': await this.selecionarGrupo(); break;
      }
    }
  }

  async entrarGrupo() {
    const { grupoId } = await inquirer.prompt([
      { type: 'input', name: 'grupoId', message: 'ID do grupo:' }
    ]);

    await db.ref(`groups/${grupoId}/members/${this.botAtivo.id}`).set({
      id: this.botAtivo.id,
      name: this.botAtivo.name,
      role: 'member',
      joinedAt: Date.now()
    });

    if (!this.botAtivo.grupos) this.botAtivo.grupos = [];
    if (!this.botAtivo.grupos.includes(grupoId)) {
      this.botAtivo.grupos.push(grupoId);
    }

    this.grupoAtivo = grupoId;
    this.salvarDados();

    console.log(chalk.green(`\n✅ Entrou no grupo ${grupoId}!`));
    await this.pausa();
  }

  async listarGrupos() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 GRUPOS\n'));
    
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Nenhum grupo.'));
    } else {
      this.botAtivo.grupos.forEach(g => {
        const ativo = this.grupoAtivo === g ? chalk.green(' [ATIVO]') : '';
        console.log(chalk.white(`📌 ${g}${ativo}`));
      });
    }
    
    await this.pausa();
  }

  async selecionarGrupo() {
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Nenhum grupo.'));
      await this.pausa();
      return;
    }

    const { grupoId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'grupoId',
        message: 'Selecione um grupo:',
        choices: this.botAtivo.grupos.map(id => ({ name: id, value: id }))
      }
    ]);

    this.grupoAtivo = grupoId;
    console.log(chalk.green(`\n✅ Grupo ${grupoId} selecionado!`));
    await this.pausa();
  }

  async gerenciarChamadas() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n📞 CHAMADAS\n'));
      
      if (this.chamadaAtiva) {
        console.log(chalk.green(`📡 Chamada ativa: ${this.tipoChamada}`));
        console.log(chalk.gray(`🔗 URL: ${this.urlMidia || 'câmera'}`));
      } else {
        console.log(chalk.yellow('⭕ Nenhuma chamada ativa'));
      }
      
      console.log('');
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha:',
          choices: [
            { name: '📹 Iniciar Chamada de Vídeo', value: 'video' },
            { name: '🎤 Iniciar Chamada de Áudio', value: 'audio' },
            { name: '🛑 Encerrar Chamada', value: 'parar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'video': await this.iniciarChamadaVideo(); break;
        case 'audio': await this.iniciarChamadaAudio(); break;
        case 'parar': await this.encerrarChamada(); break;
      }
    }
  }

  async iniciarChamadaVideo() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro!'));
      await this.pausa();
      return;
    }

    const { url } = await inquirer.prompt([
      { type: 'input', name: 'url', message: 'URL do vídeo (ou ENTER para câmera):' }
    ]);

    this.chamadaAtiva = true;
    this.tipoChamada = 'Vídeo';
    this.urlMidia = url || 'câmera';

    await db.ref(`groups/${this.grupoAtivo}/chamada`).set({
      tipo: 'video',
      url: url || null,
      botId: this.botAtivo.id,
      botName: this.botAtivo.name,
      iniciadaEm: Date.now()
    });

    io.to(this.grupoAtivo).emit('bot-stream-started', {
      type: 'video',
      url: url || null,
      botId: this.botAtivo.id,
      botName: this.botAtivo.name
    });

    console.log(chalk.green(`\n✅ Chamada de vídeo iniciada!`));
    await this.pausa();
  }

  async iniciarChamadaAudio() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro!'));
      await this.pausa();
      return;
    }

    const { url } = await inquirer.prompt([
      { type: 'input', name: 'url', message: 'URL do áudio:' }
    ]);

    this.chamadaAtiva = true;
    this.tipoChamada = 'Áudio';
    this.urlMidia = url;

    await db.ref(`groups/${this.grupoAtivo}/chamada`).set({
      tipo: 'audio',
      url: url,
      botId: this.botAtivo.id,
      botName: this.botAtivo.name,
      iniciadaEm: Date.now()
    });

    io.to(this.grupoAtivo).emit('bot-stream-started', {
      type: 'audio',
      url: url,
      botId: this.botAtivo.id,
      botName: this.botAtivo.name
    });

    console.log(chalk.green(`\n✅ Chamada de áudio iniciada!`));
    await this.pausa();
  }

  async encerrarChamada() {
    this.chamadaAtiva = false;
    this.tipoChamada = null;
    this.urlMidia = null;

    if (this.grupoAtivo) {
      await db.ref(`groups/${this.grupoAtivo}/chamada`).remove();
      io.to(this.grupoAtivo).emit('bot-stream-stopped');
    }

    console.log(chalk.yellow(`\n🛑 Chamada encerrada!`));
    await this.pausa();
  }

  async enviarMensagem() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro.'));
      await this.pausa();
      return;
    }

    const { mensagem } = await inquirer.prompt([
      { type: 'input', name: 'mensagem', message: 'Mensagem:' }
    ]);

    await this.enviarMensagemServidor(mensagem);
    console.log(chalk.green(`\n✅ Mensagem enviada!`));
    await this.pausa();
  }

  async enviarMensagemServidor(texto) {
    const timestamp = Date.now();
    const hora = new Date(timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    await db.ref(`groups/${this.grupoAtivo}/messages`).push({
      senderId: this.botAtivo.id,
      senderName: this.botAtivo.name,
      text: texto,
      timestamp: timestamp,
      time: hora
    });
    
    this.stats.mensagensEnviadas++;
  }

  async monitorarMensagens() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro.'));
      await this.pausa();
      return;
    }

    console.clear();
    console.log(chalk.cyan.bold('\n👀 MONITORANDO\n'));
    console.log(chalk.yellow('Pressione CTRL+C para parar\n'));
    console.log(chalk.white('═'.repeat(50)));

    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    const onMessage = (snapshot) => {
      const msg = snapshot.val();
      if (msg.senderId === this.botAtivo.id) return;
      
      console.log(chalk.gray(`[${msg.time}]`), chalk.cyan(msg.senderName + ':'), chalk.white(msg.text));
      this.stats.mensagensRecebidas++;
      this.executarComandos(msg);
    };

    messagesRef.limitToLast(1).on('child_added', onMessage);

    await new Promise(resolve => {
      process.on('SIGINT', () => {
        messagesRef.off('child_added', onMessage);
        console.log(chalk.yellow('\n\n👋 Monitoramento encerrado.'));
        resolve();
      });
    });
  }

  executarComandos(msg) {
    if (!msg.text) return;

    for (const comando of this.comandos) {
      try {
        const reply = (texto) => this.enviarMensagemServidor(texto);
        const bot = this.botAtivo;
        const grupo = this.grupoAtivo;
        
        const iniciarChamadaVideo = (url) => {
          this.chamadaAtiva = true;
          this.tipoChamada = 'Vídeo';
          this.urlMidia = url || 'câmera';
          db.ref(`groups/${this.grupoAtivo}/chamada`).set({
            tipo: 'video', url: url || null, botId: bot.id, botName: bot.name, iniciadaEm: Date.now()
          });
          io.to(this.grupoAtivo).emit('bot-stream-started', { type: 'video', url: url || null, botId: bot.id, botName: bot.name });
        };
        
        const iniciarChamadaAudio = (url) => {
          this.chamadaAtiva = true;
          this.tipoChamada = 'Áudio';
          this.urlMidia = url;
          db.ref(`groups/${this.grupoAtivo}/chamada`).set({
            tipo: 'audio', url: url, botId: bot.id, botName: bot.name, iniciadaEm: Date.now()
          });
          io.to(this.grupoAtivo).emit('bot-stream-started', { type: 'audio', url: url, botId: bot.id, botName: bot.name });
        };
        
        const encerrarChamada = () => {
          this.chamadaAtiva = false;
          db.ref(`groups/${this.grupoAtivo}/chamada`).remove();
          io.to(this.grupoAtivo).emit('bot-stream-stopped');
        };
        
        eval(comando.code);
        this.stats.comandosExecutados++;
      } catch (e) {}
    }
  }

  async iniciar24h() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro.'));
      await this.pausa();
      return;
    }

    this.executando = true;
    console.clear();
    console.log(chalk.green.bold('\n🚀 BOT INICIADO 24/7\n'));
    console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.name)}`));
    console.log(chalk.white(`Grupo: ${chalk.cyan(this.grupoAtivo)}`));
    console.log(chalk.cyan(`🌐 Web: ${this.serverUrl}`));

    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    messagesRef.on('child_added', (snapshot) => {
      const msg = snapshot.val();
      if (msg.senderId !== this.botAtivo.id) {
        this.executarComandos(msg);
        this.stats.mensagensRecebidas++;
      }
    });

    console.log(chalk.gray('\nPressione qualquer tecla para voltar...'));
    await this.pausa();
  }

  async parar() {
    if (!this.executando) return;
    this.executando = false;
    if (this.grupoAtivo) db.ref(`groups/${this.grupoAtivo}/messages`).off();
    console.log(chalk.yellow('\n🛑 Bot parado.'));
    await this.pausa();
  }

  async gerenciarComandos() {
    console.clear();
    console.log(chalk.cyan.bold('\n📝 COMANDOS\n'));
    console.log(chalk.yellow('Edite o arquivo comandos.js para adicionar comandos.'));
    console.log(chalk.gray('\n📁 Local: ~/bot-terminal/comandos.js'));
    await this.pausa();
  }

  async pausa() {
    await inquirer.prompt([{ type: 'input', name: 'c', message: chalk.gray('\nPressione ENTER...') }]);
  }
}

const bot = new BotTerminal();

process.on('SIGINT', async () => {
  await bot.parar();
  server.close();
  process.exit(0);
});

bot.iniciar().catch(console.error);