#!/usr/bin/env node

const firebase = require('firebase');
const chalk = require('chalk');
const figlet = require('figlet');
const inquirer = require('inquirer');
const fs = require('fs');
const path = require('path');
const express = require('express');
const os = require('os');

// ============================================
// CONFIGURAÇÃO
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBzRLpZJDMeFASIjje4SJBfTInIEO-GKVI",
  databaseURL: "https://html-785e3-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ============================================
// SERVIDOR WEB
// ============================================
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// API para obter status
app.get('/api/status', (req, res) => {
  const networkInterfaces = os.networkInterfaces();
  const ips = [];
  
  for (const name of Object.keys(networkInterfaces)) {
    for (const net of networkInterfaces[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        ips.push(net.address);
      }
    }
  }
  
  res.json({
    online: true,
    botAtivo: bot.botAtivo ? { id: bot.botAtivo.id, name: bot.botAtivo.name } : null,
    grupoAtivo: bot.grupoAtivo,
    chamadaAtiva: bot.chamadaAtiva,
    tipoChamada: bot.tipoChamada,
    urlMidia: bot.urlMidia,
    ips: ips,
    port: PORT,
    url: ips.length > 0 ? `http://${ips[0]}:${PORT}` : `http://localhost:${PORT}`
  });
});

// API para iniciar chamada
app.post('/api/chamada/iniciar', (req, res) => {
  const { tipo, url } = req.body;
  
  if (!bot.botAtivo || !bot.grupoAtivo) {
    return res.json({ erro: 'Selecione um bot e grupo primeiro' });
  }
  
  bot.chamadaAtiva = true;
  bot.tipoChamada = tipo;
  bot.urlMidia = url || null;
  
  db.ref(`groups/${bot.grupoAtivo}/chamada`).set({
    tipo: tipo,
    url: url || null,
    botId: bot.botAtivo.id,
    botName: bot.botAtivo.name,
    iniciadaEm: Date.now()
  });
  
  res.json({ sucesso: true, mensagem: `Chamada de ${tipo} iniciada!` });
});

// API para encerrar chamada
app.post('/api/chamada/encerrar', (req, res) => {
  bot.chamadaAtiva = false;
  bot.tipoChamada = null;
  bot.urlMidia = null;
  
  if (bot.grupoAtivo) {
    db.ref(`groups/${bot.grupoAtivo}/chamada`).remove();
  }
  
  res.json({ sucesso: true, mensagem: 'Chamada encerrada!' });
});

// ============================================
// CLASSE PRINCIPAL
// ============================================
class BotTerminal {
  constructor() {
    this.bots = [];
    this.botAtivo = null;
    this.grupoAtivo = null;
    this.comandos = [];
    this.executando = false;
    this.chamadaAtiva = false;
    this.tipoChamada = null;
    this.urlMidia = null;
    this.stats = { mensagensEnviadas: 0, mensagensRecebidas: 0, uptime: Date.now() };
  }

  async iniciar() {
    console.clear();
    
    console.log(chalk.cyan(figlet.textSync('BOT SERVER', { font: 'Standard' })));
    console.log(chalk.green('╔══════════════════════════════════════════════════════════╗'));
    console.log(chalk.green('║           🤖 BOT SERVER - STREAMING SIMPLES               ║'));
    console.log(chalk.green('╚══════════════════════════════════════════════════════════╝'));
    
    await this.carregarDados();
    
    // Iniciar servidor web
    app.listen(PORT, '0.0.0.0', () => {
      this.mostrarUrls();
    });
    
    this.menuPrincipal();
  }

  mostrarUrls() {
    const networkInterfaces = os.networkInterfaces();
    
    console.log(chalk.cyan('\n🌐 URLs DE ACESSO:\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    for (const name of Object.keys(networkInterfaces)) {
      for (const net of networkInterfaces[name]) {
        if (net.family === 'IPv4') {
          const url = `http://${net.address}:${PORT}`;
          if (net.internal) {
            console.log(chalk.gray(`   📱 Local: ${url}`));
          } else {
            console.log(chalk.green(`   🌍 Rede: ${url}`));
          }
        }
      }
    }
    
    console.log(chalk.white('═'.repeat(50)));
    console.log(chalk.yellow('\n📱 Acesse esse endereço no seu navegador!\n'));
  }

  async carregarDados() {
    const dataPath = path.join(__dirname, 'dados.json');
    
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      this.bots = data.bots || [];
      this.comandos = data.comandos || [];
    }
    
    try {
      const comandosModule = require('./comandos.js');
      this.comandos = [...this.comandos, ...comandosModule];
    } catch(e) {}
  }

  salvarDados() {
    fs.writeFileSync(path.join(__dirname, 'dados.json'), JSON.stringify({
      bots: this.bots,
      comandos: this.comandos
    }, null, 2));
  }

  async menuPrincipal() {
    while (true) {
      const { opcao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcao',
          message: chalk.cyan('🤖 Menu:'),
          choices: [
            { name: '📊 Dashboard', value: 'dashboard' },
            { name: '🤖 Gerenciar Bots', value: 'bots' },
            { name: '👥 Gerenciar Grupos', value: 'grupos' },
            { name: '📞 Chamadas', value: 'chamadas' },
            { name: '🌐 Ver URLs', value: 'urls' },
            { name: '💬 Enviar Mensagem', value: 'enviar' },
            { name: '🚀 Iniciar 24/7', value: 'iniciar' },
            new inquirer.Separator(),
            { name: '🚪 Sair', value: 'sair' }
          ]
        }
      ]);

      if (opcao === 'sair') { process.exit(0); }
      await this.executarOpcao(opcao);
    }
  }

  async executarOpcao(opcao) {
    const handlers = {
      'dashboard': () => this.mostrarDashboard(),
      'bots': () => this.gerenciarBots(),
      'grupos': () => this.gerenciarGrupos(),
      'chamadas': () => this.gerenciarChamadas(),
      'urls': () => { this.mostrarUrls(); return this.pausa(); },
      'enviar': () => this.enviarMensagem(),
      'iniciar': () => this.iniciar24h()
    };

    if (handlers[opcao]) await handlers[opcao]();
  }

  async mostrarDashboard() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 DASHBOARD\n'));
    console.log(chalk.white('═'.repeat(40)));
    console.log(`${chalk.white('Bot:')} ${this.botAtivo ? chalk.cyan(this.botAtivo.name) : chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Grupo:')} ${this.grupoAtivo || chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Chamada:')} ${this.chamadaAtiva ? chalk.green(this.tipoChamada) : chalk.yellow('Inativa')}`);
    console.log(chalk.white('═'.repeat(40)));
    await this.pausa();
  }

  async gerenciarBots() {
    while (true) {
      console.clear();
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Gerenciar Bots:',
          choices: [
            { name: '➕ Criar Bot', value: 'criar' },
            { name: '📋 Listar Bots', value: 'listar' },
            { name: '✅ Selecionar Bot', value: 'selecionar' },
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      if (acao === 'criar') {
        const { nome } = await inquirer.prompt([{ type: 'input', name: 'nome', message: 'Nome do bot:' }]);
        const id = `bot_${Date.now()}`;
        this.bots.push({ id, name: nome, avatar: 'https://i.imgur.com/2Vq5pZm.png', grupos: [] });
        this.salvarDados();
        console.log(chalk.green(`✅ Bot "${nome}" criado!`));
        await this.pausa();
      }
      
      if (acao === 'listar') {
        this.bots.forEach((b, i) => console.log(chalk.white(`${i+1}. ${b.name}`)));
        await this.pausa();
      }
      
      if (acao === 'selecionar' && this.bots.length > 0) {
        const { botId } = await inquirer.prompt([{
          type: 'list', name: 'botId', message: 'Selecione:',
          choices: this.bots.map(b => ({ name: b.name, value: b.id }))
        }]);
        this.botAtivo = this.bots.find(b => b.id === botId);
        console.log(chalk.green(`✅ Bot "${this.botAtivo.name}" selecionado!`));
        await this.pausa();
      }
    }
  }

  async gerenciarGrupos() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      return this.pausa();
    }

    const { acao } = await inquirer.prompt([
      {
        type: 'list',
        name: 'acao',
        message: 'Grupos:',
        choices: [
          { name: '➕ Entrar em Grupo', value: 'entrar' },
          { name: '✅ Selecionar Grupo', value: 'selecionar' },
          { name: '🔙 Voltar', value: 'voltar' }
        ]
      }
    ]);

    if (acao === 'voltar') return;

    if (acao === 'entrar') {
      const { grupoId } = await inquirer.prompt([{ type: 'input', name: 'grupoId', message: 'ID do grupo:' }]);
      await db.ref(`groups/${grupoId}/members/${this.botAtivo.id}`).set({
        id: this.botAtivo.id, name: this.botAtivo.name, role: 'member', joinedAt: Date.now()
      });
      if (!this.botAtivo.grupos) this.botAtivo.grupos = [];
      this.botAtivo.grupos.push(grupoId);
      this.grupoAtivo = grupoId;
      this.salvarDados();
      console.log(chalk.green(`✅ Entrou no grupo ${grupoId}!`));
    }

    if (acao === 'selecionar' && this.botAtivo.grupos) {
      const { grupoId } = await inquirer.prompt([{
        type: 'list', name: 'grupoId', message: 'Selecione:',
        choices: this.botAtivo.grupos.map(g => ({ name: g, value: g }))
      }]);
      this.grupoAtivo = grupoId;
      console.log(chalk.green(`✅ Grupo ${grupoId} selecionado!`));
    }
    
    await this.pausa();
  }

  async gerenciarChamadas() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo primeiro!'));
      return this.pausa();
    }

    const { acao } = await inquirer.prompt([
      {
        type: 'list',
        name: 'acao',
        message: 'Chamadas:',
        choices: [
          { name: '📹 Iniciar Vídeo', value: 'video' },
          { name: '🎤 Iniciar Áudio', value: 'audio' },
          { name: '🛑 Encerrar', value: 'parar' },
          { name: '🔙 Voltar', value: 'voltar' }
        ]
      }
    ]);

    if (acao === 'voltar') return;

    if (acao === 'video') {
      const { url } = await inquirer.prompt([{ 
        type: 'input', 
        name: 'url', 
        message: 'URL do vídeo (ou ENTER para câmera):',
        default: ''
      }]);
      
      this.chamadaAtiva = true;
      this.tipoChamada = 'Vídeo';
      this.urlMidia = url || null;
      
      await db.ref(`groups/${this.grupoAtivo}/chamada`).set({
        tipo: 'video', url: url || null, botId: this.botAtivo.id,
        botName: this.botAtivo.name, iniciadaEm: Date.now()
      });
      
      console.log(chalk.green(`\n✅ Chamada de vídeo iniciada!`));
      this.mostrarUrls();
    }

    if (acao === 'audio') {
      const { url } = await inquirer.prompt([{ type: 'input', name: 'url', message: 'URL do áudio:' }]);
      
      this.chamadaAtiva = true;
      this.tipoChamada = 'Áudio';
      this.urlMidia = url;
      
      await db.ref(`groups/${this.grupoAtivo}/chamada`).set({
        tipo: 'audio', url: url, botId: this.botAtivo.id,
        botName: this.botAtivo.name, iniciadaEm: Date.now()
      });
      
      console.log(chalk.green(`\n✅ Chamada de áudio iniciada!`));
      this.mostrarUrls();
    }

    if (acao === 'parar') {
      this.chamadaAtiva = false;
      this.tipoChamada = null;
      this.urlMidia = null;
      await db.ref(`groups/${this.grupoAtivo}/chamada`).remove();
      console.log(chalk.yellow('🛑 Chamada encerrada!'));
    }
    
    await this.pausa();
  }

  async enviarMensagem() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo!'));
      return this.pausa();
    }

    const { msg } = await inquirer.prompt([{ type: 'input', name: 'msg', message: 'Mensagem:' }]);
    
    await db.ref(`groups/${this.grupoAtivo}/messages`).push({
      senderId: this.botAtivo.id,
      senderName: this.botAtivo.name,
      text: msg,
      timestamp: Date.now(),
      time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    });
    
    console.log(chalk.green('✅ Mensagem enviada!'));
    await this.pausa();
  }

  async iniciar24h() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione bot e grupo!'));
      return this.pausa();
    }

    this.executando = true;
    console.log(chalk.green('\n🚀 Bot rodando 24/7!\n'));
    this.mostrarUrls();
    
    db.ref(`groups/${this.grupoAtivo}/messages`).on('child_added', (snap) => {
      const msg = snap.val();
      if (msg.senderId !== this.botAtivo.id) {
        console.log(chalk.gray(`[${msg.time}]`), chalk.cyan(msg.senderName), msg.text);
      }
    });
    
    await this.pausa();
  }

  async pausa() {
    await inquirer.prompt([{ type: 'input', name: 'c', message: chalk.gray('\nPressione ENTER...') }]);
  }
}

const bot = new BotTerminal();
bot.iniciar().catch(console.error);