#!/usr/bin/env node

const firebase = require('firebase');
const chalk = require('chalk');
const figlet = require('figlet');
const inquirer = require('inquirer');
const fs = require('fs');
const path = require('path');

// ============================================
// CONFIGURAÇÃO FIREBASE (APENAS PARA MENSAGENS)
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBzRLpZJDMeFASIjje4SJBfTInIEO-GKVI",
  databaseURL: "https://html-785e3-default-rtdb.firebaseio.com"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// ============================================
// ESTADO GLOBAL DO BOT (100% LOCAL)
// ============================================
class BotTerminal {
  constructor() {
    this.bots = [];              // ✅ Bots salvos LOCALMENTE
    this.botAtivo = null;
    this.grupoAtivo = null;
    this.comandos = [];          // ✅ Comandos salvos LOCALMENTE
    this.assets = [];            // ✅ Assets salvos LOCALMENTE
    this.executando = false;
    this.listeners = new Map();
    this.stats = {
      mensagensEnviadas: 0,
      mensagensRecebidas: 0,
      comandosExecutados: 0,
      uptime: Date.now()
    };
  }

  // ============================================
  // INICIALIZAÇÃO
  // ============================================
  async iniciar() {
    console.clear();
    
    console.log(chalk.cyan(figlet.textSync('BOT LOCAL', {
      font: 'Standard',
      horizontalLayout: 'default',
      verticalLayout: 'default'
    })));

    console.log(chalk.green('╔══════════════════════════════════════════════════════════╗'));
    console.log(chalk.green('║      🤖 BOT LOCAL - ARMAZENAMENTO INDIVIDUAL              ║'));
    console.log(chalk.green('║         Mensagens no Firebase • Bots no Servidor          ║'));
    console.log(chalk.green('╚══════════════════════════════════════════════════════════╝'));
    
    // Carregar dados LOCAIS
    await this.carregarDadosLocais();
    
    // Verificar conexão Firebase (apenas mensagens)
    await this.verificarConexao();
    
    // Iniciar menu principal
    this.menuPrincipal();
  }

  // ============================================
  // CARREGAR DADOS LOCAIS (NÃO COMPARTILHADOS)
  // ============================================
  async carregarDadosLocais() {
    const dataPath = path.join(__dirname, 'bots_local.json');
    
    if (fs.existsSync(dataPath)) {
      const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
      this.bots = data.bots || [];
      this.comandos = data.comandos || [];
      this.assets = data.assets || [];
      console.log(chalk.yellow(`📦 Dados LOCAIS carregados: ${this.bots.length} bots, ${this.comandos.length} comandos`));
    } else {
      console.log(chalk.yellow('📦 Nenhum dado local encontrado. Iniciando vazio.'));
    }
    
    // Carregar comandos padrão
    try {
      const comandosModule = require('./comandos.js');
      this.comandos = [...this.comandos, ...comandosModule];
    } catch(e) {
      // Arquivo de comandos não existe ainda
    }
  }

  // ============================================
  // SALVAR DADOS LOCALMENTE (NÃO VAI PARA NUVEM)
  // ============================================
  salvarDadosLocais() {
    const data = {
      bots: this.bots,
      comandos: this.comandos,
      assets: this.assets,
      ultimoBackup: Date.now()
    };
    
    fs.writeFileSync(
      path.join(__dirname, 'bots_local.json'), 
      JSON.stringify(data, null, 2)
    );
    console.log(chalk.green('💾 Dados salvos LOCALMENTE!'));
  }

  // ============================================
  // VERIFICAR CONEXÃO FIREBASE (APENAS MSG)
  // ============================================
  async verificarConexao() {
    try {
      const connectedRef = db.ref('.info/connected');
      
      connectedRef.on('value', (snap) => {
        if (snap.val() === true) {
          console.log(chalk.green('✅ Conectado ao Firebase (mensagens)!'));
        } else {
          console.log(chalk.red('❌ Desconectado do Firebase!'));
        }
      });
    } catch (error) {
      console.error(chalk.red('Erro ao conectar ao Firebase:'), error);
    }
  }

  // ============================================
  // MENU PRINCIPAL
  // ============================================
  async menuPrincipal() {
    while (true) {
      const { opcao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'opcao',
          message: chalk.cyan('🤖 O que você quer fazer?'),
          choices: [
            { name: '📊 Dashboard - Ver Status', value: 'dashboard' },
            { name: '🤖 Gerenciar Bots (LOCAIS)', value: 'bots' },
            { name: '👥 Gerenciar Grupos', value: 'grupos' },
            { name: '📝 Gerenciar Comandos (LOCAIS)', value: 'comandos' },
            { name: '🎨 Gerenciar Assets (LOCAIS)', value: 'assets' },
            { name: '💬 Enviar Mensagem', value: 'enviar' },
            { name: '👀 Monitorar Mensagens', value: 'monitorar' },
            { name: '⚙️ Configurações', value: 'config' },
            { name: '🚀 Iniciar Bot 24/7', value: 'iniciar' },
            { name: '🛑 Parar Bot', value: 'parar' },
            { name: '📊 Estatísticas', value: 'stats' },
            new inquirer.Separator(),
            { name: '🚪 Sair', value: 'sair' }
          ],
          pageSize: 15
        }
      ]);

      if (opcao === 'sair') {
        await this.pararBot();
        console.log(chalk.yellow('👋 Até logo!'));
        process.exit(0);
      }

      await this.executarOpcao(opcao);
    }
  }

  // ============================================
  // EXECUTAR OPÇÃO DO MENU
  // ============================================
  async executarOpcao(opcao) {
    const handlers = {
      'dashboard': () => this.mostrarDashboard(),
      'bots': () => this.gerenciarBots(),
      'grupos': () => this.gerenciarGrupos(),
      'comandos': () => this.gerenciarComandos(),
      'assets': () => this.gerenciarAssets(),
      'enviar': () => this.enviarMensagem(),
      'monitorar': () => this.monitorarMensagens(),
      'config': () => this.configuracoes(),
      'iniciar': () => this.iniciarBot24h(),
      'parar': () => this.pararBot(),
      'stats': () => this.mostrarEstatisticas()
    };

    if (handlers[opcao]) {
      await handlers[opcao]();
    }
  }

  // ============================================
  // DASHBOARD
  // ============================================
  async mostrarDashboard() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 DASHBOARD - BOTS LOCAIS\n'));
    console.log(chalk.white('═'.repeat(50)));
    
    const status = this.executando ? chalk.green('✅ ATIVO') : chalk.yellow('⭕ INATIVO');
    console.log(`${chalk.white('Status:')} ${status}`);
    console.log(`${chalk.white('Bot Ativo:')} ${this.botAtivo ? chalk.cyan(this.botAtivo.name) : chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Grupo Ativo:')} ${this.grupoAtivo || chalk.gray('Nenhum')}`);
    console.log(`${chalk.white('Bots Locais:')} ${chalk.yellow(this.bots.length)}`);
    console.log(`${chalk.white('Comandos Locais:')} ${chalk.yellow(this.comandos.length)}`);
    
    const uptime = Math.floor((Date.now() - this.stats.uptime) / 1000);
    const horas = Math.floor(uptime / 3600);
    const minutos = Math.floor((uptime % 3600) / 60);
    
    console.log(`${chalk.white('Uptime:')} ${chalk.green(`${horas}h ${minutos}m`)}`);
    console.log(`${chalk.white('Msgs Enviadas:')} ${chalk.blue(this.stats.mensagensEnviadas)}`);
    console.log(`${chalk.white('Msgs Recebidas:')} ${chalk.blue(this.stats.mensagensRecebidas)}`);
    
    console.log(chalk.white('\n═'.repeat(50)));
    console.log(chalk.gray('📁 Bots salvos em: bots_local.json'));
    
    await this.pausa();
  }

  // ============================================
  // GERENCIAR BOTS (100% LOCAL)
  // ============================================
  async gerenciarBots() {
    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n🤖 GERENCIAR BOTS (ARMAZENAMENTO LOCAL)\n'));
      console.log(chalk.gray('📁 Estes bots NÃO são compartilhados com outros servidores\n'));
      
      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha uma ação:',
          choices: [
            { name: '➕ Criar Novo Bot (Local)', value: 'criar' },
            { name: '📋 Listar Bots Locais', value: 'listar' },
            { name: '✅ Selecionar Bot', value: 'selecionar' },
            { name: '✏️ Editar Bot', value: 'editar' },
            { name: '🗑️ Deletar Bot', value: 'deletar' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'criar':
          await this.criarBot();
          break;
        case 'listar':
          await this.listarBots();
          break;
        case 'selecionar':
          await this.selecionarBot();
          break;
        case 'editar':
          await this.editarBot();
          break;
        case 'deletar':
          await this.deletarBot();
          break;
      }
    }
  }

  async criarBot() {
    const respostas = await inquirer.prompt([
      {
        type: 'input',
        name: 'nome',
        message: 'Nome do bot:',
        validate: input => input.length > 0 ? true : 'Nome é obrigatório'
      },
      {
        type: 'input',
        name: 'avatar',
        message: 'URL do avatar (opcional):',
        default: 'https://i.imgur.com/2Vq5pZm.png'
      }
    ]);

    // ID local - NÃO vai para Firebase
    const id = `bot_local_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    
    const bot = {
      id,
      name: respostas.nome,
      avatar: respostas.avatar,
      criadoEm: Date.now(),
      status: 'offline',
      grupos: [],
      local: true  // ✅ Marcador de bot local
    };

    this.bots.push(bot);
    
    // ✅ Salvar APENAS localmente
    this.salvarDadosLocais();
    
    console.log(chalk.green(`\n✅ Bot "${bot.name}" criado LOCALMENTE!`));
    console.log(chalk.gray(`📁 Salvo em: bots_local.json`));
    console.log(chalk.yellow('⚠️ Este bot NÃO aparece em outros servidores'));
    
    await this.pausa();
  }

  async listarBots() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 BOTS LOCAIS\n'));
    console.log(chalk.gray('📁 Estes bots existem apenas neste servidor\n'));
    
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot local cadastrado.'));
    } else {
      this.bots.forEach((bot, index) => {
        const ativo = this.botAtivo?.id === bot.id ? chalk.green(' [ATIVO]') : '';
        console.log(chalk.white(`${index + 1}. ${bot.name}${ativo}`));
        console.log(chalk.gray(`   ID Local: ${bot.id}`));
        console.log(chalk.gray(`   Criado: ${new Date(bot.criadoEm).toLocaleString()}`));
        console.log('');
      });
    }
    
    await this.pausa();
  }

  async selecionarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot local cadastrado.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione um bot local:',
        choices: this.bots.map(bot => ({
          name: `${bot.name} (${bot.id})`,
          value: bot.id
        }))
      }
    ]);

    this.botAtivo = this.bots.find(b => b.id === botId);
    console.log(chalk.green(`\n✅ Bot local "${this.botAtivo.name}" selecionado!`));
    
    await this.pausa();
  }

  async editarBot() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    const respostas = await inquirer.prompt([
      {
        type: 'input',
        name: 'nome',
        message: 'Novo nome:',
        default: this.botAtivo.name
      },
      {
        type: 'input',
        name: 'avatar',
        message: 'Nova URL do avatar:',
        default: this.botAtivo.avatar
      }
    ]);

    this.botAtivo.name = respostas.nome;
    this.botAtivo.avatar = respostas.avatar;
    
    // ✅ Salvar localmente
    this.salvarDadosLocais();
    
    console.log(chalk.green(`\n✅ Bot local atualizado!`));
    await this.pausa();
  }

  async deletarBot() {
    if (this.bots.length === 0) {
      console.log(chalk.yellow('Nenhum bot para deletar.'));
      await this.pausa();
      return;
    }

    const { botId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'botId',
        message: 'Selecione o bot local para deletar:',
        choices: this.bots.map(bot => ({
          name: bot.name,
          value: bot.id
        }))
      }
    ]);

    const { confirmar } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmar',
        message: 'Tem certeza? Esta ação não pode ser desfeita!',
        default: false
      }
    ]);

    if (confirmar) {
      this.bots = this.bots.filter(b => b.id !== botId);
      
      if (this.botAtivo?.id === botId) {
        this.botAtivo = null;
      }
      
      // ✅ Salvar localmente
      this.salvarDadosLocais();
      console.log(chalk.green('✅ Bot local deletado!'));
    }
    
    await this.pausa();
  }

  // ============================================
  // GERENCIAR GRUPOS (USANDO FIREBASE)
  // ============================================
  async gerenciarGrupos() {
    if (!this.botAtivo) {
      console.log(chalk.yellow('Selecione um bot primeiro!'));
      await this.pausa();
      return;
    }

    while (true) {
      console.clear();
      console.log(chalk.cyan.bold('\n👥 GERENCIAR GRUPOS (Firebase)\n'));
      console.log(chalk.white(`Bot ativo: ${chalk.cyan(this.botAtivo.name)}`));
      
      if (this.grupoAtivo) {
        console.log(chalk.white(`Grupo atual: ${chalk.green(this.grupoAtivo)}`));
      }
      
      console.log('');

      const { acao } = await inquirer.prompt([
        {
          type: 'list',
          name: 'acao',
          message: 'Escolha uma ação:',
          choices: [
            { name: '➕ Entrar em Grupo', value: 'entrar' },
            { name: '📋 Listar Grupos', value: 'listar' },
            { name: '✅ Selecionar Grupo', value: 'selecionar' },
            { name: '🚪 Sair do Grupo', value: 'sair' },
            new inquirer.Separator(),
            { name: '🔙 Voltar', value: 'voltar' }
          ]
        }
      ]);

      if (acao === 'voltar') break;

      switch (acao) {
        case 'entrar':
          await this.entrarGrupo();
          break;
        case 'listar':
          await this.listarGrupos();
          break;
        case 'selecionar':
          await this.selecionarGrupo();
          break;
        case 'sair':
          await this.sairGrupo();
          break;
      }
    }
  }

  async entrarGrupo() {
    const { grupoId } = await inquirer.prompt([
      {
        type: 'input',
        name: 'grupoId',
        message: 'ID do grupo:',
        validate: input => input.length > 0 ? true : 'ID é obrigatório'
      }
    ]);

    // Registrar no Firebase
    await db.ref(`groups/${grupoId}/members/${this.botAtivo.id}`).set({
      id: this.botAtivo.id,
      name: this.botAtivo.name,
      role: 'member',
      joinedAt: Date.now()
    });

    if (!this.botAtivo.grupos) this.botAtivo.grupos = [];
    if (!this.botAtivo.grupos.includes(grupoId)) {
      this.botAtivo.grupos.push(grupoId);
    }

    this.grupoAtivo = grupoId;
    this.salvarDadosLocais();

    console.log(chalk.green(`\n✅ Entrou no grupo ${grupoId}!`));
    await this.pausa();
  }

  async listarGrupos() {
    console.clear();
    console.log(chalk.cyan.bold('\n📋 GRUPOS DO BOT\n'));
    
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Bot não está em nenhum grupo.'));
    } else {
      for (const grupoId of this.botAtivo.grupos) {
        const ativo = this.grupoAtivo === grupoId ? chalk.green(' [ATIVO]') : '';
        console.log(chalk.white(`📌 Grupo: ${grupoId}${ativo}`));
      }
    }
    
    await this.pausa();
  }

  async selecionarGrupo() {
    if (!this.botAtivo.grupos || this.botAtivo.grupos.length === 0) {
      console.log(chalk.yellow('Bot não está em nenhum grupo.'));
      await this.pausa();
      return;
    }

    const { grupoId } = await inquirer.prompt([
      {
        type: 'list',
        name: 'grupoId',
        message: 'Selecione um grupo:',
        choices: this.botAtivo.grupos.map(id => ({
          name: id,
          value: id
        }))
      }
    ]);

    this.grupoAtivo = grupoId;
    console.log(chalk.green(`\n✅ Grupo ${grupoId} selecionado!`));
    await this.pausa();
  }

  async sairGrupo() {
    if (!this.grupoAtivo) {
      console.log(chalk.yellow('Nenhum grupo selecionado.'));
      await this.pausa();
      return;
    }

    const { confirmar } = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmar',
        message: `Sair do grupo ${this.grupoAtivo}?`,
        default: false
      }
    ]);

    if (confirmar) {
      await db.ref(`groups/${this.grupoAtivo}/members/${this.botAtivo.id}`).remove();
      
      this.botAtivo.grupos = this.botAtivo.grupos.filter(g => g !== this.grupoAtivo);
      this.grupoAtivo = null;
      
      this.salvarDadosLocais();
      console.log(chalk.green('✅ Saiu do grupo!'));
    }
    
    await this.pausa();
  }

  // ============================================
  // ENVIAR MENSAGEM (VIA FIREBASE)
  // ============================================
  async enviarMensagem() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um bot e um grupo primeiro.'));
      await this.pausa();
      return;
    }

    const { mensagem } = await inquirer.prompt([
      {
        type: 'input',
        name: 'mensagem',
        message: 'Digite a mensagem:',
        validate: input => input.length > 0 ? true : 'Mensagem é obrigatória'
      }
    ]);

    await this.enviarMensagemFirebase(mensagem);
    
    console.log(chalk.green(`\n✅ Mensagem enviada!`));
    await this.pausa();
  }

  async enviarMensagemFirebase(texto, tipo = 'text') {
    const timestamp = Date.now();
    const horaFormatada = new Date(timestamp).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });

    const mensagem = {
      senderId: this.botAtivo.id,
      senderName: this.botAtivo.name,
      text: texto,
      timestamp: timestamp,
      time: horaFormatada,
      type: tipo
    };

    await db.ref(`groups/${this.grupoAtivo}/messages`).push(mensagem);
    
    this.stats.mensagensEnviadas++;
  }

  // ============================================
  // MONITORAR MENSAGENS
  // ============================================
  async monitorarMensagens() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um bot e um grupo primeiro.'));
      await this.pausa();
      return;
    }

    console.clear();
    console.log(chalk.cyan.bold('\n👀 MONITORANDO MENSAGENS\n'));
    console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.name)}`));
    console.log(chalk.white(`Grupo: ${chalk.cyan(this.grupoAtivo)}`));
    console.log(chalk.yellow('\nPressione CTRL+C para parar\n'));
    console.log(chalk.white('═'.repeat(60)));

    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    const onMessage = (snapshot) => {
      const msg = snapshot.val();
      
      if (msg.senderId === this.botAtivo.id) return;
      
      const hora = msg.time || new Date(msg.timestamp).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      });
      
      console.log(chalk.gray(`[${hora}]`), 
                  chalk.cyan(msg.senderName + ':'), 
                  chalk.white(msg.text || '[Mídia]'));
      
      this.stats.mensagensRecebidas++;
      
      // Executar comandos
      this.executarComandos(msg);
    };

    messagesRef.limitToLast(1).on('child_added', onMessage);

    await new Promise(resolve => {
      process.on('SIGINT', () => {
        messagesRef.off('child_added', onMessage);
        console.log(chalk.yellow('\n\n👋 Monitoramento encerrado.'));
        resolve();
        setTimeout(() => this.menuPrincipal(), 1000);
      });
    });
  }

  // ============================================
  // EXECUTAR COMANDOS
  // ============================================
  executarComandos(msg) {
    if (!msg.text) return;

    for (const comando of this.comandos) {
      try {
        const reply = (texto) => {
          this.enviarMensagemFirebase(texto);
        };

        const bot = this.botAtivo;
        const grupo = this.grupoAtivo;
        
        eval(comando.code);
        
        this.stats.comandosExecutados++;
      } catch (error) {
        console.error(chalk.red(`Erro no comando ${comando.name}:`), error.message);
      }
    }
  }

  // ============================================
  // INICIAR BOT 24/7
  // ============================================
  async iniciarBot24h() {
    if (!this.botAtivo || !this.grupoAtivo) {
      console.log(chalk.yellow('Selecione um bot e um grupo primeiro.'));
      await this.pausa();
      return;
    }

    this.executando = true;

    console.clear();
    console.log(chalk.green.bold('\n🚀 INICIANDO BOT LOCAL 24/7\n'));
    console.log(chalk.white(`Bot: ${chalk.cyan(this.botAtivo.name)}`));
    console.log(chalk.white(`Grupo: ${chalk.cyan(this.grupoAtivo)}`));
    console.log(chalk.green('\n✅ Bot iniciado!\n'));

    const messagesRef = db.ref(`groups/${this.grupoAtivo}/messages`);
    
    messagesRef.on('child_added', (snapshot) => {
      const msg = snapshot.val();
      
      if (msg.senderId !== this.botAtivo.id) {
        this.executarComandos(msg);
        this.stats.mensagensRecebidas++;
      }
    });

    console.log(chalk.gray('Pressione qualquer tecla para voltar...'));
    await this.pausa();
  }

  async pararBot() {
    if (!this.executando) {
      console.log(chalk.yellow('Bot não está em execução.'));
      await this.pausa();
      return;
    }

    this.executando = false;

    if (this.grupoAtivo) {
      db.ref(`groups/${this.grupoAtivo}/messages`).off();
    }

    console.log(chalk.yellow('\n🛑 Bot parado.'));
    await this.pausa();
  }

  async mostrarEstatisticas() {
    console.clear();
    console.log(chalk.cyan.bold('\n📊 ESTATÍSTICAS\n'));
    
    const uptime = Math.floor((Date.now() - this.stats.uptime) / 1000);
    const horas = Math.floor(uptime / 3600);
    const minutos = Math.floor((uptime % 3600) / 60);
    
    console.log(chalk.white(`⏱️  Uptime: ${chalk.green(`${horas}h ${minutos}m`)}`));
    console.log(chalk.white(`📨 Enviadas: ${chalk.blue(this.stats.mensagensEnviadas)}`));
    console.log(chalk.white(`📥 Recebidas: ${chalk.blue(this.stats.mensagensRecebidas)}`));
    console.log(chalk.white(`🤖 Bots locais: ${chalk.yellow(this.bots.length)}`));
    
    await this.pausa();
  }

  async configuracoes() {
    console.clear();
    console.log(chalk.cyan.bold('\n⚙️ CONFIGURAÇÕES\n'));
    console.log(chalk.gray('📁 Arquivo de bots: bots_local.json'));
    console.log(chalk.gray('📁 Arquivo de comandos: comandos.js'));
    console.log(chalk.yellow('\nOs bots são salvos apenas neste servidor.'));
    
    await this.pausa();
  }

  // ============================================
  // UTILITÁRIOS
  // ============================================
  async pausa() {
    await inquirer.prompt([
      {
        type: 'input',
        name: 'continuar',
        message: chalk.gray('\nPressione ENTER para continuar...')
      }
    ]);
  }
}

// ============================================
// INICIAR BOT
// ============================================
const bot = new BotTerminal();

process.on('SIGINT', async () => {
  console.log(chalk.yellow('\n\n🛑 Encerrando...'));
  await bot.pararBot();
  process.exit(0);
});

bot.iniciar().catch(console.error);